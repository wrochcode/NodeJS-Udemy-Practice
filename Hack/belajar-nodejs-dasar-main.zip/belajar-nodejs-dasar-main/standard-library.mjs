import os from "os";

console.info(os.platform());
console.table(os.cpus());
