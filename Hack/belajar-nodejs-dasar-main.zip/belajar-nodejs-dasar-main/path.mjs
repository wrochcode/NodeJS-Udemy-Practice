import path from "path";

const file = "/Users/khannedy/contoh.txt";

console.info(path.dirname(file));
console.info(path.basename(file));
console.info(path.extname(file));
