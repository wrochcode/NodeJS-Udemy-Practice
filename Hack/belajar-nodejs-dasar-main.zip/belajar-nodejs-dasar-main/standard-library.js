import os from "os";

console.info(os.platform());
console.table(os.cpus());

// error karena bukan js modules file
