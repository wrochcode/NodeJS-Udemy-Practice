
setTimeout(() => {
    console.info("Hello Globals");
}, 2000);
